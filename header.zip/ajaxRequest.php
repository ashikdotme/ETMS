<?php 
require_once('config.php');

if(isset($_POST['email'])){
	$email = $_POST['email'];

	$stm=$pdo->prepare("SELECT u_id,email,password FROM em_users WHERE email=?");
    $stm->execute(array($email));
    $userCount=$stm->rowCount();

    if($userCount == 1){

    // $userData = $stm->fetchAll(PDO::FETCH_ASSOC);

    	$new_password = rand(99999,99999999);

    	$stm=$pdo->prepare("UPDATE em_users SET password = ? WHERE email=?");
    	$stm->execute(array(SHA1($new_password),$email));

    	
    	$message = "Your New Password Is:";
    	$message .= $new_password;
    	$mail = mail($email,"Reset Password",$message);
    	if($mail){
    		echo $new_password. " Your Password Reset Success";
    	}

    }else{
    	echo "Email Does't Match!";
    }
 


}


 ?>